package util;

/**
 * Implements an indexed priority queue.
 *  This queue allows to change values of its elements in logarithmic time.
 *  Elements of this queue are successive integers, and their values are also integers.
 *
 * @author Viacheslav Krakhotin
 *
 */
public class IndexedIntMaxPriorityQueue {
	private int amount;
	private int maxNumber;
	private int[] queue;
	private int[] positions;
	private int[] values;
	
	public IndexedIntMaxPriorityQueue(int capacity) {
		this.maxNumber = capacity - 1;
		this.amount = 0;
		this.queue = new int[capacity + 1];
		this.positions = new int[capacity];
		this.values = new int[capacity];
	}
	
	/**
	 * Add a new element to the queue.
	 * @param key The element to be added. It must be non-negative and less than capacity of the queue. 
	 * @param value Value of the element.
	 * @return True is the element has been added; false otherwise. 
	 */
	public boolean add(int key, int value) {
		if ((key < 0) || (key > maxNumber) || (positions[key] > 0))
			return false;
		amount ++;
		values[key] = value;
		positions[key] = amount;
		queue[amount] = key;
		swim(amount);
		return true;
	}
	
	/**
	 * Decrement value of the element by 1.
	 * @param key The element.
	 */
	public void decrementValue(int key) {
		if ((key < 0) || (key > maxNumber) || (positions[key] == 0))
			return;
		values[key] --;
		sink(positions[key]);
	}
	
	/**
	 * Increment value of the element by 1.
	 *  If the element is absent in the queue, put it and assign the value 1.  
	 * @param key The element.
	 */
	public void incrementValue(int key) {
		if ((key < 0) || (key > maxNumber))
			return;
		if (positions[key] == 0) {
			add(key, 1);
		} else {
			values[key] ++;
			swim(positions[key]);
		}
	}
	
	/**
	 * Decrement value of the element.
	 * @param key The element.
	 * @param value The number to be subtracted from the elements value.
	 */
	public void decrementValue(int key, int value) {
		if ((key < 0) || (key > maxNumber) || (positions[key] == 0))
			return;
		values[key] -= value;
		sink(positions[key]);
	}
	
	/**
	 * Increment value of the element.
	 *  If the element is absent in the queue, put it and assign the given value.  
	 * @param key The element.
	 * @param value The number to be added to the elements value.
	 */
	public void incrementValue(int key, int value) {
		if ((key < 0) || (key > maxNumber))
			return;
		if (positions[key] == 0) {
			add(key, value);
		} else {
			values[key] += value;
			swim(positions[key]);
		}
	}
	
	/**
	 * Get first element.
	 * @return The element with the maximum value and its value. Returns null if the queue is empty.
	 */
	public KeyValue peek() {
		if (amount <= 0)
			return null;
		int key = queue[1];
		return new KeyValue(key, values[key]);
	}
	
	/**
	 * Get value for the element.
	 * @param key The element.
	 * @return Value of the element. 
	 */
	public int getValue(int key) {
		if ((key < 0) || (key > maxNumber) || (positions[key] == 0))
			return 0;
		return values[key];
	}
	
	private void exchangePositions(int pos1, int pos2) {
		int key1 = queue[pos1];
		int key2 = queue[pos2];
		queue[pos1] = key2;
		queue[pos2] = key1;
		positions[key1] = pos2;
		positions[key2] = pos1;
	}
	
	private void swim(int position) {
		int currentPos = position;
		int parentPos = position / 2;
		while ((parentPos > 0) && (values[queue[parentPos]] < values[queue[currentPos]])) {
			exchangePositions(parentPos, currentPos);
			currentPos = parentPos;
			parentPos = currentPos / 2;
		}
	}
	
	private void sink(int position) {
		int currentPos = position;
		int nextPos = 2 * currentPos;
		while (nextPos <= amount) {
			int pos2 = nextPos + 1;
			if ((pos2 <= amount) && (values[queue[pos2]] > values[queue[nextPos]]))
				nextPos = pos2;
			if (values[queue[currentPos]] >= values[queue[nextPos]])
				return;
			exchangePositions(currentPos, nextPos);
			currentPos = nextPos;
			nextPos = 2 * currentPos;
		}
	}
	
	public static class KeyValue {
		private final int key;
		private final int value;
		
		public KeyValue(int key, int value) {
			this.key = key;
			this.value = value;
		}

		public int getKey() {
			return key;
		}

		public int getValue() {
			return value;
		}
	}

}
