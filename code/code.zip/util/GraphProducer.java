package util;

import java.io.FileNotFoundException;
import java.io.PrintWriter;

/**
 * Class for creating graphs for testing purposes.
 * 
 * @author Viacheslav Krakhotin
 *
 */
public class GraphProducer {

	private static void printEdge(int from, int to, PrintWriter out) {
		out.println(from + " " + to);
	}
	
	/**
	 * Create a ring of cliques (full graphs).
	 * Each clique is connected with two others.
	 * @param cliqueNumber Number of cliques
	 * @param cliqueSize Size of clique
	 * @param out PrintWriter
	 */
	public static void cliqueRing(int cliqueNumber, int cliqueSize, PrintWriter out) {
		int gap = 1;
		while (gap < cliqueSize) {
			gap *= 10;
		}
		int cliqueBase = 0;
		for (int clique = 0; clique < cliqueNumber; clique ++) {
			int prevVertex = cliqueBase;
			if (clique == 0)
				prevVertex = cliqueNumber * gap;
			prevVertex += cliqueSize - 1;
			cliqueBase += gap;
			printEdge(cliqueBase, prevVertex, out);
			for (int vertexNum = cliqueBase; vertexNum < cliqueBase + cliqueSize; vertexNum ++) {
				for (int neighborNum = cliqueBase; neighborNum < cliqueBase + cliqueSize; neighborNum ++)
					if (vertexNum != neighborNum)
						printEdge(vertexNum, neighborNum, out);
			}
			int nextVertex = cliqueBase + gap;
			if (clique == cliqueNumber - 1)
				nextVertex = gap;
			printEdge(cliqueBase + cliqueSize - 1, nextVertex, out);
		}
	}
	
	public static void main(String[] args) {
		try (PrintWriter out = new PrintWriter("data/cliques_5_30.txt")) {
			cliqueRing(30, 5, out);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

	}

}
