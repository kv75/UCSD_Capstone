package graph;

/**
 * Represents undirected weighted edge in the UndirectedGraph.
 *
 * @author Viacheslav Krakhotin
 * 
 */
class WeightedEdge {
	private final SimpleVertex startVertex;
	private final SimpleVertex endVertex;
	private int weight;
	
	public WeightedEdge(SimpleVertex from, SimpleVertex to, int weight) {
		super();
		if (from.getKey() <= to.getKey()) {
			this.startVertex = from;
			this.endVertex = to;
		} else {
			this.startVertex = to;
			this.endVertex = from;
		}
		this.weight = weight;
	}

	public WeightedEdge(SimpleVertex from, SimpleVertex to) {
		this(from, to, 1);
	}

	/**
	 * @return Start vertex of the edge (vertex with the lowest key)
	 */
	public SimpleVertex getStart() {
		return startVertex;
	}

	/**
	 * @return End vertex of the edge (vertex with the highest key)
	 */
	public SimpleVertex getEnd() {
		return endVertex;
	}

	/**
	 * @return Weight of the edge
	 */
	public int getWeight() {
		return weight;
	}

	/**
	 * Set weight of the edge
	 * @param weight The weight
	 */
	public void setWeight(int weight) {
		this.weight = weight;
	}
	
	/**
	 * Increase weight of the edge
	 * @param weight Value to be added to the weight of the edge.
	 */
	public void addWeight(int weight) {
		this.weight += weight;
	}

}
