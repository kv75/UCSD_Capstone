package graph;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Queue;

/**
 * Provides method split to partition graph using Girvan-Newman algorithm.
 * 
 * @author Viacheslav Krakhotin.
 *
 */
public class GirvanNewmanSolver {
	
	private final DirectedGraph graph;
	private final GnVertex[] vertices;
	private final GnEdge[] edges;
	private final int numVertices;
	private final int numEdges;
	private int componentCount;
	private double modularity;

	public GirvanNewmanSolver(DirectedGraph graph) {
		super();
		this.graph = graph;
		this.numVertices = graph.getNumVertices();
		this.numEdges = graph.getNumEdges();
		this.vertices = new GnVertex[numVertices];
		this.edges = new GnEdge[numEdges];
		for (int vertexId = 0; vertexId < numVertices; vertexId ++ ) {
			InOutVertex v = graph.getVertexById(vertexId);
			vertices[vertexId] = new GnVertex(v);
			for (DirectedEdge edge : v.getEdges()) {
				this.edges[edge.getId()] = new GnEdge(edge);
			}
		}
	}
	
	/**
	 * Splits graph into components using Girvan-Newman algorithm.
	 * @param count Desired number of components.
	 *  If zero, the algorithm will stop when removing next edge does not provide gain in modularity. 
	 * @param removeByOne If true, only 2 directed edges (forward and backward) are removed during one iteration.
	 * @return List of subgraphs.
	 */
	public List<GraphComponent> split(int count, boolean removeByOne) {
		for (int id = 0; id < numEdges; id ++) {
			edges[id].setActive(true);
		}
		if (count > numVertices) {
			count = numVertices;
		}
		componentCount = 0;
		modularity = Double.NEGATIVE_INFINITY;
		List<GnEdge> lastDeletedEdges = new ArrayList<GnEdge>();
		while (needsProcessing(count, lastDeletedEdges)) {
			lastDeletedEdges.clear();
			List<GnEdge> heaviestEdges = findHeaviestEdges();
			GnEdge firstEdge = null;
			for (GnEdge edge : heaviestEdges) {
				if (firstEdge == null || firstEdge.getDegree() > edge.getDegree())
					firstEdge = edge;
			}
			for (GnEdge edge : heaviestEdges) {
				if (!removeByOne || edge.equals(firstEdge) || edge.getSource().isBackTo(firstEdge.getSource())) {
					edge.setActive(false);
					lastDeletedEdges.add(edge);
				}
				/*
				System.out.println(componentCount
						+ " components; edge "
						+ edge.getSource().getStart().getKey()
						+ " - " + edge.getSource().getEnd().getKey()
						+ "; score " + edge.getScore());
				*/
			}
		}
		List<GraphComponent> clusters = getConnectedComponents();
		for (int id = 0; id < numEdges; id ++) {
			edges[id].setActive(true);
			edges[id].reset();
		}
		return clusters;
	}
	
	/**
	 * Check if the algorithm has to be continued.
	 * @param maxCount Desired number of components.
	 * @param deletedEdges Edges deleted in the previous iteration.
	 * @return True if the algorithm has to be continued; false otherwise. 
	 */
	private boolean needsProcessing(int maxCount, List<GnEdge> deletedEdges) {
		int newComponentCount = getComponentCount();
		if (newComponentCount > componentCount) {
			double newModularity = calculateModularity();
			// If new modularity is less than previous,
			// add deleted edges to the graph and stop iterations. 
			if (maxCount == 0 && newModularity <= modularity) {
				for (GnEdge edge : deletedEdges)
					edge.setActive(true);
				return false;
			}
			modularity = newModularity;
			componentCount = newComponentCount;
			/*
			System.out.println(componentCount
					+ " components; modularity = "
					+ modularity);
			*/
			if (maxCount > 0 && componentCount >= maxCount)
				return false;
		}
		return true;
	}

	/**
	 * Assign vertices to connected components of the graph.
	 * This method uses breadth-first search.
	 * @return The number of connected components.
	 */
	private int getComponentCount() {
		boolean[] visited = new boolean[numVertices];
		int component = 0;
		Queue<InOutVertex> queue = new ArrayDeque<InOutVertex>(numVertices);
		for (int id = 0; id < numVertices; id ++) {
			if (!visited[id]) {
				InOutVertex currVertex = graph.getVertexById(id);
				while (currVertex != null) {
					vertices[currVertex.getId()].setComponentId(component);
					for (DirectedEdge edge : currVertex.getEdges()) {
						if (edges[edge.getId()].isActive()) {
							InOutVertex neighbor = edge.getEnd();
							int neighborId = neighbor.getId();
							if (!visited[neighborId]) {
								visited[neighborId] = true;
								queue.offer(neighbor);
							}
						}
					}
					for (DirectedEdge edge : currVertex.getInEdges()) {
						if (edges[edge.getId()].isActive()) {
							InOutVertex neighbor = edge.getStart();
							int neighborId = neighbor.getId();
							if (!visited[neighborId]) {
								visited[neighborId] = true;
								queue.offer(neighbor);
							}
						}
					}
					currVertex = queue.poll();
				}
				component ++;
			}
		}
		return component;
	}
	
	/**
	 * Calculate modularity of the current graph partition
	 * @return Modularity of the current graph partition
	 */
	private double calculateModularity() {
		// sumOfProducts is the sum of products of vertex degrees (undirected, or out-degrees)
		// for each vertex pair within the same component;
		// each vertex pair is accounted twice (for both orders of vertices);
		// pairs with the same vertices are accounted once
		long sumOfProducts = 0;
		// numInnerEdges is the number of directed edges within the same component,
		// or twice the number of undirected edges within the same component
		int numInnerEdges = 0;
		for (int id1 = 0; id1 < numVertices; id1 ++) {
			InOutVertex vertex1 = graph.getVertexById(id1);
			int component1 = vertices[id1].getComponentId();
			for (int id2 = 0; id2 < numVertices; id2 ++) {
				InOutVertex vertex2 = graph.getVertexById(id2);
				if (vertices[id2].getComponentId() == component1) {
					sumOfProducts += vertex1.getOutDegree() * vertex2.getOutDegree();
				}
			}
		}
		for (int edgeId = 0; edgeId < numEdges; edgeId ++) {
			GnEdge edge = edges[edgeId];
			if (vertices[edge.getSource().getStart().getId()].getComponentId() == vertices[edge.getSource().getEnd().getId()].getComponentId()) {
				numInnerEdges ++;
			};
		}
		return (numInnerEdges - (sumOfProducts + 0.) / numEdges) / numEdges;
	}

	/**
	 * Splits graph into connected components. Removed edges are ignored. 
 	 * This method uses breadth-first search.
	 * @return List of all connected components of the graph.
	 */
	private List<GraphComponent> getConnectedComponents() {
		List<GraphComponent> res = new ArrayList<GraphComponent>();
		boolean[] visited = new boolean[numVertices];
		Queue<InOutVertex> queue = new ArrayDeque<InOutVertex>(numVertices);
		int currComponentId = -1;
		for (int id = 0; id < numVertices; id ++) {
			if (!visited[id]) {
				List<InOutVertex> componentVertices = new ArrayList<InOutVertex>();
				currComponentId ++;
				InOutVertex currVertex = graph.getVertexById(id);
				while (currVertex != null) {
					componentVertices.add(currVertex);
					for (DirectedEdge edge : currVertex.getEdges()) {
						if (edges[edge.getId()].isActive()) {
							InOutVertex neighbor = edge.getEnd();
							if (!visited[neighbor.getId()]) {
								visited[neighbor.getId()] = true;
								queue.offer(neighbor);
							}
						}
					}
					for (DirectedEdge edge : currVertex.getInEdges()) {
						if (edges[edge.getId()].isActive()) {
							InOutVertex neighbor = edge.getStart();
							if (!visited[neighbor.getId()]) {
								visited[neighbor.getId()] = true;
								queue.offer(neighbor);
							}
						}
					}
					currVertex = queue.poll();
				}
				if ((currComponentId == 0) && (componentVertices.size() == numVertices)) {
					// The graph is connected.
					// We do not need to split it, so return the graph itself to save time and memory. 
					res.add(graph);
					return res;
				} else {
					DirectedGraph subGraph = graph.getSubgraph(componentVertices);
					subGraph.setComponentId(currComponentId);
					res.add(subGraph);
				}
			}
		}
		return res;
	}
	
	/**
	 * Performs an iteration of Girvan-Newman algorithm.
	 * @return List of the edges with highest betweenness.
	 */
	private List<GnEdge> findHeaviestEdges() {
		for (int id = 0; id < numEdges; id ++) {
			edges[id].reset();
		}
		for (int id = 0; id < numVertices; id ++) {
			allPathsBFS(vertices[id]);
		}
		List<GnEdge> res = new ArrayList<GnEdge>();
		double maxScore = 0.;
		for (int id = 0; id < numEdges; id ++) {
			GnEdge edge = edges[id];
			if (edge.getScore() > maxScore) {
				maxScore = edge.getScore();
			}
		}
		maxScore *= 0.99999999999;
		for (int id = 0; id < numEdges; id ++) {
			GnEdge edge = edges[id];
			if (edge.getScore() > maxScore) {
				res.add(edge);
			}
		}
		return res;
	}

	/**
	 * Performs breadth-first search from start vertex to all other vertices.
	 * All shortest paths are taking into account. 
	 * For each edge, contribution to edge betweenness is calculated.
	 * @param start Source vertex for breadth-first search.
	 */
	private void allPathsBFS(GnVertex start) {
		// Stack of visited vertices.
		ArrayList<GnVertex> stack = new ArrayList<GnVertex>(numVertices);
		// Queue for breadth-first search.
		Queue<GnVertex> queue = new ArrayDeque<GnVertex>(numVertices);
		for (int id = 0; id < numVertices; id ++) {
			vertices[id].reset();
		}
		// For each vertex, distance is a distance to the start;
		// weight is the number of shortest paths to the vertex;
		// score is the contribution to betweenness of the vertex,
		// that is the normalized amount of shortest paths from start to other vertices
		// that go through this vertex.
		// For each edge, weight is the number of the shortest paths to the end of the edge
		// that go through this edge.
		start.setDistance(0);
		start.addToWeight(1);
		GnVertex currVertex = start;
		while (currVertex != null) {
			stack.add(currVertex);
			int nextDistance = currVertex.getDistance() + 1;
			long currWeight = currVertex.getWeight();
			for (DirectedEdge sourceEdge : getSourceVertex(currVertex).getEdges()) {
				GnEdge edge = edges[sourceEdge.getId()];
				if (edge.isActive()) {
					GnVertex nextVertex = vertices[sourceEdge.getEnd().getId()];
					if (nextDistance <= nextVertex.getDistance()) {
						// The edge is a part of the shortest path to its end.
						nextVertex.addPreviousEdge(edge);
						edge.setWeight(currWeight);
						nextVertex.addToWeight(currWeight);
						if (nextDistance < nextVertex.getDistance()) {
							// nextVertex is not visited yet
							nextVertex.setDistance(nextDistance);
							queue.add(nextVertex);
						}
					}
				}
			}
			currVertex = queue.poll();
		}
		while (!stack.isEmpty()) {
			currVertex = stack.remove(stack.size() - 1);
			List<GnEdge> prevEdges = currVertex.getPreviousEdges();
			if ((prevEdges != null) && (prevEdges.size() > 0)) {
				// We add 1, since the normalized amount of the shortest paths
				// from start vertex to currVertex is 1, by definition.
				// currVertex.getScore() here corresponds to paths to further vertices.
				double score = (currVertex.getScore() + 1.) / currVertex.getWeight();
				for (GnEdge edge : prevEdges) {
					// Contribution to edge betweenness is proportional to
					// weight of this edge divided by sum of weights
					// of all previous edges of currVertex (that is currVertex.getWeight()).
					double edgeScore = score * edge.getWeight();
					edge.addToScore(edgeScore);
					vertices[edge.getSource().getStart().getId()].addToScore(edgeScore);
				}
			}
		}
	}
	
	private InOutVertex getSourceVertex(GnVertex vertex) {
		return graph.getVertexById(vertex.getId());
	}
	
	/**
	 * @return Modularity of the obtained partition
	 */
	public double getModularity() {
		return modularity;
	}

	private static class GnVertex {
		
		private final int id;
		// see description of these fields in comments for allPathsBFS
		private int distance;
		private double score;
		private long weight;
		// list of incoming edges that are parts of shortest paths to this vertex 
		private ArrayList<GnEdge> prevEdges;
		private int componentId;

		public GnVertex(InOutVertex source) {
			this.id = source.getId();
		}

		public int getId() {
			return id;
		}

		@Override
		public final int hashCode() {
			// Just return hashCode of the id, since id is unique.
			return Integer.valueOf(id).hashCode();
		}
		
		@Override
		public final boolean equals(Object o) {
			if (o == this)
				return true;
			if (!(o instanceof GnVertex))
				return false;
			return (this.id == ((GnVertex)o).id);
		}
		
		public void reset() {
			prevEdges = null;
			distance = Integer.MAX_VALUE;
			score = 0.;
			weight = 0;
		}

		public int getDistance() {
			return distance;
		}

		public void setDistance(int distance) {
			this.distance = distance;
		}

		public double getScore() {
			return score;
		}

		public void addToScore(double value) {
			this.score += value;
		}
		
		public void addPreviousEdge(GnEdge edge) {
			if (prevEdges == null) {
				prevEdges = new ArrayList<GnEdge>();
			}
			prevEdges.add(edge);
		}
		
		public List<GnEdge> getPreviousEdges() {
			return prevEdges;
		}

		public long getWeight() {
			return weight;
		}

		public void addToWeight(long value) {
			this.weight += value;
		}

		public int getComponentId() {
			return componentId;
		}

		public void setComponentId(int componentId) {
			this.componentId = componentId;
		}

	}
	
	private class GnEdge {
		
		private final DirectedEdge source;
		private double score;
		private long weight;
		private boolean active;
		
		public GnEdge(DirectedEdge source) {
			this.source = source;
		}

		public boolean isActive() {
			return active;
		}

		public void setActive(boolean active) {
			this.active = active;
		}
		
		public void reset() {
			score = 0.;
			weight = 0;
		}

		public double getScore() {
			return score;
		}

		public void addToScore(double value) {
			this.score += value;
		}

		public long getWeight() {
			return weight;
		}

		public void setWeight(long weight) {
			this.weight = weight;
		}

		public DirectedEdge getSource() {
			return source;
		}
		
		public int getDegree() {
			int res = 0;
			for (DirectedEdge edge : source.getStart().getEdges()) {
				if (edges[edge.getId()].isActive())
					res++;
			}
			for (DirectedEdge edge : source.getStart().getInEdges()) {
				if (edges[edge.getId()].isActive())
					res++;
			}
			for (DirectedEdge edge : source.getEnd().getEdges()) {
				if (edges[edge.getId()].isActive())
					res++;
			}
			for (DirectedEdge edge : source.getEnd().getEdges()) {
				if (edges[edge.getId()].isActive())
					res++;
			}
			return res;
		}
		
		@Override
		public final boolean equals(Object o) {
			if (o == this)
				return true;
			if (!(o instanceof GnEdge))
				return false;
			return (this.source.getId() == ((GnEdge)o).getSource().getId());
		}
	}

}
