package graph;

import java.util.HashMap;
import java.util.HashSet;

/**
 * @author Viacheslav Krakhotin
 *
 */
public interface GraphComponent {
    /**
     * Creates a vertex with the given number.
     * @param num - key of the vertex
     */
    public void addVertex(int num);
    
    /**
     * Creates an edge from the first vertex to the second.
     * @param from - key of the first vertex
     * @param to - key of the second vertex
     */
    public void addEdge(int from, int to);

    /**
     * Return the graph's connections in a readable format. 
     * The keys in this HashMap are the vertices in the graph.
     * The values are the nodes that are reachable via a directed
     * edge from the corresponding key. 
	 * The returned representation ignores edge weights and 
	 * multi-edges.
     * @return HashMap representing the graph
     */
    public HashMap<Integer, HashSet<Integer>> exportGraph();

    /**
     * @return Identifier of current graph.
     */
    public int getComponentId();
	
    /**
     * Inform the graph that its construction has been finished.
     * The graph will be immutable after calling this method.
     */
    public void fixSize();
    
    /**
     * Find central vertex of the graph.
     * @return key of the center vertex
     */
    public int getCenter();
}
