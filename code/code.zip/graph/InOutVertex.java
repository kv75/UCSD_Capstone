package graph;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a node in the DirectedGraph.
 *
 * @author Viacheslav Krakhotin
 * 
 */
class InOutVertex {
	private final ArrayList<DirectedEdge> outEdges;
	private final ArrayList<DirectedEdge> inEdges;
	private final int key;
	private int id;
	
	public InOutVertex(int key) {
		super();
		this.key = key;
		this.outEdges = new ArrayList<DirectedEdge>();
		this.inEdges = new ArrayList<DirectedEdge>();
		this.id = key;
	}

	/**
	 * @return Key of the vertex
	 */
	public int getKey() {
		return key;
	}

	/**
	 * @return Identifier of the vertex.
	 */
	public int getId() {
		return id;
	}

	/**
	 * Set identifier of the vertex
	 * @param id Identifier
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Add an edge to the vertex
	 * @param edge An edge to add
	 */
	public void addEdge(DirectedEdge edge) {
		if (edge.getStart().getKey() == key)
			outEdges.add(edge);
		if (edge.getEnd().getKey() == key)
			inEdges.add(edge);
	}

	@Override
	public final int hashCode() {
		// Just return hashCode of the key, since keys are unique.
		return Integer.valueOf(key).hashCode();
	}
	
	@Override
	public final boolean equals(Object o) {
		if (o == this)
			return true;
		if (!(o instanceof InOutVertex))
			return false;
		return (this.key == ((InOutVertex)o).key);
	}
	
	/**
	 * Minimizes the storage of edge lists.
	 * This method should be called when no more edges
	 * will be added to the vertex.  
	 */
	public void fixSize(){
		outEdges.trimToSize();
		inEdges.trimToSize();
	}
	
	/**
	 * @return Degree of the vertex (the number of all adjacent edges)
	 */
	public int getDegree() {
		return outEdges.size() + inEdges.size();
	}
	
	/**
	 * @return Out-degree of the vertex (the number of outgoing edges)
	 */
	public int getOutDegree() {
		return outEdges.size();
	}
	
	/**
	 * @return In-degree of the vertex (the number of incoming edges)
	 */
	public int getInDegree() {
		return inEdges.size();
	}
	
	/**
	 * Get all outgoing edges 
	 * @return List of all edges outgoing from the vertex
	 */
	public List<DirectedEdge> getEdges() {
		return outEdges;
	}

	/**
	 * Get all incoming edges
	 * @return List of all edges incoming to the vertex
	 */
	public List<DirectedEdge> getInEdges() {
		return inEdges;
	}

	/**
	 * Get all (out-)neighbors
	 * @return List of all vertices that are adjacent to this one
	 * 	via outgoing edges from this.
	 */
	public List<InOutVertex> getNeighbors() {
		List<InOutVertex> vertices = new ArrayList<InOutVertex>(outEdges.size());
		for (DirectedEdge edge : outEdges) {
			vertices.add(edge.getEnd());
		}
		return vertices;
	}

	/**
	 * Get all in-neighbors
	 * @return List of all vertices that are adjacent to this one
	 * 	via incoming edges to this.
	 */
	public List<InOutVertex> getInNeighbors() {
		List<InOutVertex> vertices = new ArrayList<InOutVertex>(inEdges.size());
		for (DirectedEdge edge : inEdges) {
			vertices.add(edge.getStart());
		}
		return vertices;
	}
}
