package graph;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Queue;

/**
 * Represents directed unweighted graph that accepts parallel edges and self-loops.
 * 
 * @author Viacheslav Krakhotin.
 *
 */
public class DirectedGraph implements GraphComponent {
	private int numVertices;
	private int numEdges;
	private int componentId;
	private final Map<Integer, InOutVertex> keyToVertex;
	private InOutVertex[] vertices;
	
	public DirectedGraph() {
		super();
		this.numVertices = 0;
		this.numEdges = 0;
		this.componentId = 0;
		this.keyToVertex = new HashMap<Integer, InOutVertex>();
		this.vertices = null;
	}

	/**
	 * @return The number of vertices in the graph
	 */
	public int getNumVertices() {
		return numVertices;
	}

	/**
	 * @return The number of edges in the graph
	 */
	public int getNumEdges() {
		return numEdges;
	}

	/* (non-Javadoc)
	 * @see graph.GraphComponent#getComponentId()
	 */
	public int getComponentId() {
		return componentId;
	}

	/**
	 * Set identifier for the graph
	 * @param componentId - identifier
	 */
	public void setComponentId(int componentId) {
		this.componentId = componentId;
	}

	/* (non-Javadoc)
	 * @see graph.GraphComponent#addVertex(int)
	 */
	@Override
	public void addVertex(int num) {
		if (!keyToVertex.containsKey(num)) {
			keyToVertex.put(num, new InOutVertex(num));
			numVertices ++;
		}
	}

	/* (non-Javadoc)
	 * @see graph.GraphComponent#addEdge(int, int)
	 */
	@Override
	public void addEdge(int from, int to) {
		InOutVertex fromVertex = keyToVertex.get(from);
		if (fromVertex == null)
			return;
		InOutVertex toVertex = keyToVertex.get(to);
		if (toVertex == null)
			return;
		DirectedEdge newEdge = new DirectedEdge(fromVertex, toVertex, numEdges);
		//edges.add(newEdge);
		numEdges ++;
		fromVertex.addEdge(newEdge);
		if (from != to)
			toVertex.addEdge(newEdge);
	}

	/* (non-Javadoc)
	 * @see graph.GraphComponent#exportGraph()
	 */
	@Override
	public HashMap<Integer, HashSet<Integer>> exportGraph() {
		HashMap<Integer, HashSet<Integer>> res = new HashMap<Integer, HashSet<Integer>>();
		for (InOutVertex v : keyToVertex.values()) {
			HashSet<Integer> neighborKeys = new HashSet<Integer>();
			for (InOutVertex neighbor : v.getNeighbors())
				neighborKeys.add(neighbor.getKey());
			res.put(v.getKey(), neighborKeys);
		}
		return res;
	}

	/* (non-Javadoc)
	 * @see graph.GraphComponent#fixSize()
	 */
	@Override
	public void fixSize() {
		vertices = new InOutVertex[numVertices];
		int currentId = 0;
		for (InOutVertex vertex : keyToVertex.values()) {
			vertex.fixSize();
			vertices[currentId] = vertex;
			vertex.setId(currentId);
			currentId ++;
		}
	}
	
	/**
	 * @return collection of all graph vertices
	 */
	public Collection<InOutVertex> getVertices() {
		return keyToVertex.values();
	}
	
	/**
	 * Return vertex by its key
	 * @param key
	 * @return vertex with given key
	 */
	public InOutVertex getVertexByKey(int key) {
		return keyToVertex.get(key);
	}
	
	/**
	 * Return vertex by its identifier
	 * @param id - identifier
	 * @return vertex with given identifier
	 */
	public InOutVertex getVertexById(int id) {
		return vertices[id];
	}

	/**
	 * Constructs subgraph by list of its vertices.
	 * @param vertexList List of all vertices that belongs to subgraph. 
	 * @return Subgraph
	 */
	public DirectedGraph getSubgraph(List<InOutVertex> vertexList) {
		DirectedGraph res = new DirectedGraph();
		for (InOutVertex vertex : vertexList)
			res.addVertex(vertex.getKey());
		for (InOutVertex vertex : vertexList) {
			int curNum = vertex.getKey();
			for (InOutVertex neighbor : vertex.getNeighbors()) {
				// Method addEdge will skip edge if neighbor does not belong to the subgraph.
				res.addEdge(curNum, neighbor.getKey());
			}
		}
		res.fixSize();
		return res;
	}

	/**
	 * Splits graph into connected components (not SCC).
 	 * This method uses breadth-first search.
	 * @param retainIds If true, componentId's of the subgraphs are the same as for initial graph. 
	 * @return List of all connected components of the graph.
	 */
	public List<GraphComponent> getConnectedComponents(boolean retainIds) {
		List<GraphComponent> res = new ArrayList<GraphComponent>();
		boolean[] visited = new boolean[numVertices];
		Queue<InOutVertex> queue = new ArrayDeque<InOutVertex>(numVertices);
		int currComponentId = -1;
		for (int id = 0; id < numVertices; id ++) {
			if (!visited[id]) {
				InOutVertex source = vertices[id];
				List<InOutVertex> componentVertices = new ArrayList<InOutVertex>();
				currComponentId ++;
				InOutVertex currVertex = source;
				while (currVertex != null) {
					componentVertices.add(currVertex);
					for (InOutVertex neighbor : currVertex.getNeighbors()) {
						if (!visited[neighbor.getId()]) {
							visited[neighbor.getId()] = true;
							queue.offer(neighbor);
						}
					}
					for (InOutVertex neighbor : currVertex.getInNeighbors()) {
						if (!visited[neighbor.getId()]) {
							visited[neighbor.getId()] = true;
							queue.offer(neighbor);
						}
					}
					currVertex = queue.poll();
				}
				if ((currComponentId == 0) && (componentVertices.size() == numVertices)) {
					// The graph is connected.
					// We do not need to split it, so return the graph itself to save time and memory. 
					res.add(this);
					return res;
				} else {
					DirectedGraph subGraph = getSubgraph(componentVertices);
					if (retainIds)
						subGraph.setComponentId(this.componentId);
					else
						subGraph.setComponentId(currComponentId);
					res.add(subGraph);
				}
			}
		}
		return res;
	}

	/* (non-Javadoc)
	 * @see graph.GraphComponent#getCenter()
	 */
	@Override
	public int getCenter() {
		return new CentralityFinder().getCenter().getKey();
	}
	
	/**
	 * Class for finding central vertex of the graph using betweenness centrality.
	 *
	 */
	private class CentralityFinder {
		
		private final double[] fullScores;
		
		public CentralityFinder() {
			this.fullScores = new double[numVertices];
		}
		
		public InOutVertex getCenter() {
			for (int id = 0; id < numVertices; id ++) {
				allPathsBFS(vertices[id]);
			}
			InOutVertex res = null;
			double maxScore = -1.;
			for (int id = 0; id < numVertices; id ++) {
				if (maxScore < fullScores[id]) {
					res = vertices[id];
					maxScore = fullScores[id];
				}
			}
			//System.out.println(" [score " + maxScore + "] ");
			return res;
		}

		private void allPathsBFS(InOutVertex start) {
			ArrayList<InOutVertex> stack = new ArrayList<InOutVertex>(numVertices);
			Queue<InOutVertex> queue = new ArrayDeque<InOutVertex>(numVertices);
			int[] distances = new int[numVertices];
			long weights[] = new long[numVertices];
			ArrayList<ArrayList<InOutVertex>> previous = new ArrayList<ArrayList<InOutVertex>>(numVertices);
			for (int id = 0; id < numVertices; id ++) {
				distances[id] = Integer.MAX_VALUE;
				previous.add(new ArrayList<InOutVertex>());
			}
			distances[start.getId()] = 0;
			weights[start.getId()] = 1;
			InOutVertex currVertex = start;
			while (currVertex != null) {
				stack.add(currVertex);
				int currId = currVertex.getId();
				int nextDistance = distances[currId] + 1;
				long currWeight = weights[currId];
				for (DirectedEdge edge : vertices[currId].getEdges()) {
					InOutVertex nextVertex = edge.getEnd();
					int nextId = nextVertex.getId();
					if (nextDistance <= distances[nextId]) {
						previous.get(nextId).add(currVertex);
						weights[nextId] += currWeight;
						if (nextDistance < distances[nextId]) {
							// not visited yet
							distances[nextId] = nextDistance;
							queue.add(nextVertex);
						}
					}
				}
				currVertex = queue.poll();
			}
			double[] scores = new double[numVertices];
			while (!stack.isEmpty()) {
				currVertex = stack.remove(stack.size() - 1);
				int currId = currVertex.getId(); 
				ArrayList<InOutVertex> prevVertices = previous.get(currId);
				if (prevVertices.size() > 0) {
					fullScores[currId] += scores[currId];
					long currWeight = weights[currId];
					double score = (scores[currId] + 1.) / currWeight;
					for (InOutVertex prev : prevVertices) {
						int prevId = prev.getId();
						scores[prevId] += score * weights[prevId];
					}
				} else {
					//System.out.println(scores[currId]);
				}
			}
		}
		
	}
	
}
