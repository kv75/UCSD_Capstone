package graph;

/**
 * Represents directed unweighted edge in the DirectedGraph.
 *
 * @author Viacheslav Krakhotin
 * 
 */
class DirectedEdge {
	private final InOutVertex startVertex;
	private final InOutVertex endVertex;
	private int id;

	public DirectedEdge(InOutVertex from, InOutVertex to, int id) {
		super();
		this.startVertex = from;
		this.endVertex = to;
		this.id = id;
	}

	public DirectedEdge(InOutVertex from, InOutVertex to) {
		this(from, to, 0);
	}

	/**
	 * @return First (tail) vertex of the edge
	 */
	public InOutVertex getStart() {
		return startVertex;
	}

	/**
	 * @return Second (head) vertex of the edge
	 */
	public InOutVertex getEnd() {
		return endVertex;
	}

	/**
	 * @return Identifier of the edge
	 */
	public int getId() {
		return id;
	}

	/**
	 * Set identifier of the edge
	 * @param id Identifier
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Check if the edge is opposite to other edge.
	 * @param other The other edge
	 * @return True if this and the other edges connect the same vertices, but in different directions.
	 */
	public boolean isBackTo(DirectedEdge other) {
		if (other == null)
			return false;
		return (startVertex.getKey() == other.getEnd().getKey() && endVertex.getKey() == other.getStart().getKey());
	}

	@Override
	public boolean equals(Object o) {
		if (o == this)
			return true;
		if (!(o instanceof DirectedEdge))
			return false;
		DirectedEdge that = (DirectedEdge)o;
		return (this.getStart().getKey() == that.getStart().getKey() && this.getEnd().getKey() == that.getEnd().getKey());
	}
}
