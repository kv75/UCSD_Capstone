package graph;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Queue;

/**
 * Represents undirected weighted graph that accepts self-loops, but not parallel edges.
 * 
 * @author Viacheslav Krakhotin.
 *
 */
public class UndirectedGraph implements GraphComponent{
	private int numVertices;
	private int numEdges;
	private int componentId;
	private int totalWeight;
	private final Map<Integer, SimpleVertex> keyToVertex;
	private SimpleVertex[] vertices;
	
	public UndirectedGraph() {
		super();
		this.numVertices = 0;
		this.numEdges = 0;
		this.componentId = 0;
		this.totalWeight = 0;
		this.keyToVertex = new HashMap<Integer, SimpleVertex>();
		this.vertices = null;
	}

	/* (non-Javadoc)
	 * @see graph.GraphComponent#addVertex(int)
	 */
	public void addVertex(int num) {
		if (!keyToVertex.containsKey(num)) {
			keyToVertex.put(num, new SimpleVertex(num));
			numVertices ++;
		}
	}
	
	/**
     * Create a weighed edge between the first and the second vertices.
     * If an edge between these vertices already exists, no new edge is created,
     * but weight of the existing edge is increased by the weight parameter. 
     * @param from - key of the first vertex
     * @param to - key of the second vertex
	 * @param weight - weight of the edge
	 */
	public void addEdge(int from, int to, int weight) {
		SimpleVertex fromVertex = keyToVertex.get(from);
		if (fromVertex == null)
			return;
		SimpleVertex toVertex = keyToVertex.get(to);
		if (toVertex == null)
			return;
		WeightedEdge edge = fromVertex.getEdgeTo(to);
		if (edge == null) {
			edge = new WeightedEdge(fromVertex, toVertex, weight);
			fromVertex.addEdge(edge);
			if (from != to)
				toVertex.addEdge(edge);
			numEdges ++;
		} else {
			edge.addWeight(weight);
		}
		totalWeight += 2 * weight;
	}

	/**
	 * @return The number of vertices in the graph
	 */
	public int getNumVertices() {
		return numVertices;
	}

	/**
	 * @return The number of edges in the graph
	 */
	public int getNumEdges() {
		return numEdges;
	}

	/* (non-Javadoc)
	 * @see graph.GraphComponent#getComponentId()
	 */
	public int getComponentId() {
		return componentId;
	}

	/**
	 * Set identifier for the graph
	 * @param componentId - identifier
	 */
	public void setComponentId(int componentId) {
		this.componentId = componentId;
	}

	/* (non-Javadoc)
	 * @see graph.GraphComponent#fixSize()
	 */
	public void fixSize() {
		vertices = new SimpleVertex[numVertices];
		int currentId = 0;
		for (SimpleVertex vertex : keyToVertex.values()) {
			vertex.fixSize();
			vertices[currentId] = vertex;
			vertex.setId(currentId);
			currentId ++;
		}
	}
	
	/**
	 * @return collection of all graph vertices
	 */
	public Collection<SimpleVertex> getVertices() {
		return keyToVertex.values();
	}
	
	/**
	 * @return collection of all graph edges
	 */
	public Collection<WeightedEdge> getEdges() {
		Collection<WeightedEdge> res = new ArrayList<WeightedEdge> (numEdges);
		for (SimpleVertex v : keyToVertex.values())
			res.addAll(v.getOwnedEdges());
		return res;
	}
	
	/**
	 * Return vertex by its key
	 * @param key
	 * @return vertex with given key
	 */
	public SimpleVertex getVertexByKey(int key) {
		return keyToVertex.get(key);
	}
	
	/**
	 * Return vertex by its identifier
	 * @param id - identifier
	 * @return vertex with given identifier
	 */
	public SimpleVertex getVertexById(int id) {
		return vertices[id];
	}

	/**
	 * @return twice the sum of weights of all edges
	 */
	public int getTotalWeight() {
		return totalWeight;
	}
			
	/**
	 * Constructs subgraph by list of its vertices.
	 * @param vertexList List of all vertices that belongs to subgraph. 
	 * @return Subgraph
	 */
	public UndirectedGraph getSubgraph(List<SimpleVertex> vertexList) {
		UndirectedGraph res = new UndirectedGraph();
		for (SimpleVertex vertex : vertexList)
			res.addVertex(vertex.getKey());
		for (SimpleVertex vertex : vertexList) {
			int curNum = vertex.getKey();
			for (WeightedEdge edge : vertex.getOwnedEdges()) {
				// Method addEdge will skip edge if neighbor does not belong to the subgraph.
				res.addEdge(curNum, edge.getEnd().getKey(), edge.getWeight());
			}
		}
		res.fixSize();
		return res;
	}

	/* (non-Javadoc)
	 * @see graph.GraphComponent#addEdge(int, int)
	 */
	@Override
	public void addEdge(int from, int to) {
		if (from <= to)
			addEdge(from, to, 1);
	}

	/* (non-Javadoc)
	 * @see graph.GraphComponent#exportGraph()
	 */
	@Override
	public HashMap<Integer, HashSet<Integer>> exportGraph() {
		HashMap<Integer, HashSet<Integer>> res = new HashMap<Integer, HashSet<Integer>>();
		for (SimpleVertex v : keyToVertex.values()) {
			HashSet<Integer> neighborsNum = new HashSet<Integer>();
			for (EdgeVertexPair pair : v.getNeighbors())
				neighborsNum.add(pair.getVertex().getKey());
			res.put(v.getKey(), neighborsNum);
		}
		return res;
	}

	/* (non-Javadoc)
	 * @see graph.GraphComponent#getCenter()
	 */
	@Override
	public int getCenter() {
		return new CentralityFinder().getCenter().getKey();
	}

	/**
	 * Class for finding central vertex of the graph using betweenness centrality.
	 *
	 */
	private class CentralityFinder {
		
		private final double[] fullScores;
		
		public CentralityFinder() {
			this.fullScores = new double[numVertices];
		}
		
		public SimpleVertex getCenter() {
			for (int id = 0; id < numVertices; id ++) {
				allPathsBFS(vertices[id]);
			}
			SimpleVertex res = null;
			double maxScore = -1.;
			for (int id = 0; id < numVertices; id ++) {
				if (maxScore < fullScores[id]) {
					res = vertices[id];
					maxScore = fullScores[id];
				}
			}
			//System.out.println(" [score " + maxScore + "] ");
			return res;
		}

		private void allPathsBFS(SimpleVertex start) {
			ArrayList<SimpleVertex> stack = new ArrayList<SimpleVertex>(numVertices);
			Queue<SimpleVertex> queue = new ArrayDeque<SimpleVertex>(numVertices);
			int[] distances = new int[numVertices];
			long weights[] = new long[numVertices];
			ArrayList<ArrayList<SimpleVertex>> previous = new ArrayList<ArrayList<SimpleVertex>>(numVertices);
			for (int id = 0; id < numVertices; id ++) {
				distances[id] = Integer.MAX_VALUE;
				previous.add(new ArrayList<SimpleVertex>());
			}
			distances[start.getId()] = 0;
			weights[start.getId()] = 1;
			SimpleVertex currVertex = start;
			while (currVertex != null) {
				stack.add(currVertex);
				int currId = currVertex.getId();
				int nextDistance = distances[currId] + 1;
				long currWeight = weights[currId];
				for (EdgeVertexPair pair : vertices[currId].getNeighbors()) {
					SimpleVertex nextVertex = pair.getVertex();
					int nextId = nextVertex.getId();
					if (nextDistance <= distances[nextId]) {
						previous.get(nextId).add(currVertex);
						weights[nextId] += currWeight;
						if (nextDistance < distances[nextId]) {
							// not visited yet
							distances[nextId] = nextDistance;
							queue.add(nextVertex);
						}
					}
				}
				currVertex = queue.poll();
			}
			double[] scores = new double[numVertices];
			while (!stack.isEmpty()) {
				currVertex = stack.remove(stack.size() - 1);
				int currId = currVertex.getId(); 
				ArrayList<SimpleVertex> prevVertices = previous.get(currId);
				if (prevVertices.size() > 0) {
					fullScores[currId] += scores[currId];
					long currWeight = weights[currId];
					double score = (scores[currId] + 1.) / currWeight;
					for (SimpleVertex prev : prevVertices) {
						int prevId = prev.getId();
						scores[prevId] += score * weights[prevId];
					}
				} else {
					//System.out.println(scores[currId]);
				}
			}
		}
		
	}
	
}
