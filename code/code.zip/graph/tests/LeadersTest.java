package graph.tests;

import java.util.ArrayList;
import java.util.List;

import graph.DirectedGraph;
import graph.GraphComponent;
import graph.LeadersSolver;

/**
 * Class for running the algorithm with predefined leaders.
 * 
 * @author Viacheslav Krakhotin
 *
 */
public class LeadersTest extends AbstractTest<DirectedGraph> {

	private List<Integer> sources = new ArrayList<Integer>();
	
	public static void main(String[] args) {
		LeadersTest test = new LeadersTest(); 
		test.run();
	}
	
	@SuppressWarnings("unused")
	private void facebook1000Sources() {
		sources.add(73);
		sources.add(195);
		sources.add(428);
		sources.add(767);
		sources.add(773);
		sources.add(546);
		sources.add(890);
		sources.add(848);
		sources.add(223);
		sources.add(652);
		sources.add(368);
		sources.add(631);
		sources.add(133);
		sources.add(687);
		sources.add(636);
		sources.add(265);
		sources.add(0);
		sources.add(823);
		sources.add(743);
	}

	@SuppressWarnings("unused")
	private void facebook2000Sources() {
		sources.add(568); 
		sources.add(198); 
		sources.add(1000);
		sources.add(1082);
		sources.add(558);
		sources.add(1071);
		sources.add(155);
		sources.add(1360);
		sources.add(1917);
		sources.add(1321);
		sources.add(572);
		sources.add(1484);
		sources.add(1785);
		sources.add(1957);
		sources.add(1270);
		sources.add(195);
		sources.add(1456);
		sources.add(973);
		sources.add(765);
		sources.add(1472);
		sources.add(1200);
		sources.add(667);
		sources.add(1805);
		sources.add(1381);
		sources.add(1617);
		sources.add(371);
		sources.add(565);
		sources.add(1188);
		sources.add(1857);
		sources.add(851);
	}

	@SuppressWarnings("unused")
	private void cliqueSources() {
		for (int i = 1; i <= 15; i ++) {
			sources.add(20 * i);
		}
	}
	
	private void facebookUcsdSources() {
		sources.add(6603);
		sources.add(5030);
		sources.add(3206);
		sources.add(7361);
		sources.add(12256);
		sources.add(11646);
		sources.add(12016);
		sources.add(1537);
		sources.add(2635);
		sources.add(8177);
		sources.add(6723);
		sources.add(14697);
		sources.add(8109);
		sources.add(6352);
		sources.add(4950);
		sources.add(11403);
		sources.add(1938);
		sources.add(1360);
		sources.add(4514);
	}
	
	@Override
	protected DirectedGraph newGraph() {
		return new DirectedGraph();
	}

	@Override
	protected String testName() {
		return "Partition with 19 predefined leaders";
	}

	@Override
	protected String getFileName() {
		//return "cliques_5_30.txt";
		//return "facebook_1000.txt";
		//return "facebook_2000.txt";
		return "facebook_ucsd.txt";
	}

	@Override
	protected int getDelay() {
		return 0;
	}
	
	@Override
	protected void prepareData() {
		//cliqueSources();
		//facebook1000Sources();
		//facebook2000Sources();
		facebookUcsdSources();
	}

	@Override
	protected List<GraphComponent> split(DirectedGraph graph) {
		setCalcCenters(false);
		LeadersSolver solver = new LeadersSolver(graph);
		List<GraphComponent> res = solver.split(sources, true);
		setModularity(solver.getModularity());
		return res;
	}

}
