package graph.tests;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.List;

import graph.GraphComponent;
import graph.LouvainSolver;
import graph.UndirectedGraph;

/**
 * Class for running Louvain algorithm.
 * 
 * @author Viacheslav Krakhotin
 *
 */
public class LouvainTest extends AbstractTest<UndirectedGraph> {

	public static void main(String[] args) {
		LouvainTest test = new LouvainTest();
		test.run();
	}

	@Override
	protected UndirectedGraph newGraph() {
		return new UndirectedGraph();
	}

	@Override
	protected String testName() {
		return "Partition with Louvain algorithm";
	}

	@Override
	protected String getFileName() {
		//return "cliques_5_30.txt";
		//return "facebook_1000.txt";
		//return "facebook_2000.txt";
		return "facebook_ucsd.txt";
	}

	@Override
	protected int getDelay() {
		return 0;
	}

	@Override
	protected List<GraphComponent> split(UndirectedGraph graph) {
		setCalcCenters(true);
		List<GraphComponent> res = null;
		try (PrintWriter out = new PrintWriter("data/louvain9.txt")) {
			LouvainSolver solver = new LouvainSolver(graph);
			res = solver.split(LouvainSolver.IterationMode.BFS, false);
			setModularity(solver.getModularity());
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return res;
	}

}
