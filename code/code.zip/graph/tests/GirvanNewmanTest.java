package graph.tests;

import java.util.List;

import graph.DirectedGraph;
import graph.GirvanNewmanSolver;
import graph.GraphComponent;

/**
 * Class for running Girvan-Newman algorithm.
 * 
 * @author Viacheslav Krakhotin
 *
 */
public class GirvanNewmanTest extends AbstractTest<DirectedGraph> {

	public static void main(String[] args) {
		GirvanNewmanTest test = new GirvanNewmanTest();
		test.run();
	}

	@Override
	protected DirectedGraph newGraph() {
		return new DirectedGraph();
	}

	@Override
	protected String testName() {
		return "Partition with Girvan - Newman algorithm";
	}

	@Override
	protected String getFileName() {
		//return "cliques_5_30.txt";
		return "facebook_1000.txt";
		//return "facebook_2000.txt";
	}

	@Override
	protected int getDelay() {
		return 0;
	}

	@Override
	protected List<GraphComponent> split(DirectedGraph graph) {
		setCalcCenters(true);
		GirvanNewmanSolver solver = new GirvanNewmanSolver(graph);
		List<GraphComponent> res = solver.split(0, true);
		setModularity(solver.getModularity());
		return res;
	}

}
