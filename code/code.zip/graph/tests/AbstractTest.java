package graph.tests;

import java.util.List;
import java.util.Set;

import graph.GraphComponent;
import util.GraphLoader;

/**
 * Abstract generic class for running clastering algorithms on graphs.
 * 
 * @author Viacheslav Krakhotin
 *
 */
public abstract class AbstractTest<T extends GraphComponent> {
	
	private T graph;
	private String filename;
	private String feedback;
	private double modularity = 0.;
	private boolean calcCenters = false;
	
	/**
	 * Create new graph.
	 * @return New graph that implements GraphComponent interface.
	 */
	protected abstract T newGraph();
	
	/**
	 * @return Caption of the test.
	 */
	protected abstract String testName();
	
	/**
	 * @return Name of file with graph.
	 */
	protected abstract String getFileName();
	
	/**
	 * Runs the clustering algorithm on the graph. 
	 * @param graph 
	 * @return List of components
	 */
	protected abstract List<GraphComponent> split(T graph);

	/**
	 * Set delay before starting the algorithm.
	 * Useful for connecting to profiler.
	 * @return Delay, in milliseconds. 
	 */
	protected int getDelay() {
		return 0;
	}
	
	/**
	 * Prepare input data for the algorithm.
	 * Running time of this method is not included in running time calculation.
	 */
	protected void prepareData() {
		//
	}

	/**
	 * Set modularity to display.
	 * @param value Obtained modularity.
	 */
	protected void setModularity(double value) {
		modularity = value;
	}
	
	/**
	 * @param value If true, centers of the components will be calculated. This operation may be time-consuming.
	 */
	protected void setCalcCenters(boolean value) {
		calcCenters = value;
	}
	
	public void run() {
        try {
        	System.out.println("Running test " + testName() + "\n");
        	graph = newGraph();
        	filename = getFileName();
            GraphLoader.loadGraph(graph, "data/" + filename);
            feedback = "\nGRAPH: " + filename;
    		System.gc();
    		prepareData();
    		int delayTime = getDelay();
    		if (delayTime > 0) {
        		try {
        		    Thread.sleep(60000);
        		} catch(InterruptedException ex) {
        		    Thread.currentThread().interrupt();
        		}    			
    		}
            long time1 = System.nanoTime();
            List<GraphComponent> components = split(graph);
            long time2 = System.nanoTime();
            for (GraphComponent component : components) {
                Set<Integer> keys = component.exportGraph().keySet();
                String centers = "";
                if (calcCenters)
                	centers = "Center (" + component.getCenter() + "). ";
            	feedback += "\nCOMPONENT (" + component.getComponentId() + "). " + centers + "Size " + keys.size() + ". " + keys + ".";
            }
            feedback += "\n";
            feedback += "\nComponent count : = " + components.size();
            feedback += "\nModularity = " + modularity;
            feedback += "\nRunning time = " + ((time2 - time1) / 1000000) + " ms";
        } catch (Exception e) {
            feedback = "An error occurred during runtime.\n" + feedback + "\nError during runtime: " + e;
            e.printStackTrace();
        }
		System.out.println(feedback);
	}

}
