package graph;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Represents a node in the UndirectedGraph.
 *
 * @author Viacheslav Krakhotin
 * 
 */
class SimpleVertex {
	private final Map<Integer, WeightedEdge> outEdges;
	private final Map<Integer, WeightedEdge> inEdges;
	private final int key;
	private int id;
	
	public SimpleVertex(int key) {
		super();
		this.key = key;
		this.outEdges = new HashMap<Integer, WeightedEdge>();
		this.inEdges = new HashMap<Integer, WeightedEdge>();
		this.id = key;
	}

	/**
	 * Add an edge to the vertex
	 * @param edge An edge to add
	 */
	public void addEdge(WeightedEdge edge) {
		if (edge.getStart().getKey() == key)
			outEdges.put(edge.getEnd().getKey(), edge);
		if (edge.getEnd().getKey() == key)
			inEdges.put(edge.getStart().getKey(), edge);
	}
	
	/**
	 * @return Key of the vertex
	 */
	public final int getKey() {
		return key;
	}

	@Override
	public final int hashCode() {
		// Just return hashCode of the num, since nums are unique.
		return ((Integer)key).hashCode();
	}
	
	@Override
	public final boolean equals(Object o) {
		if (o == this)
			return true;
		if (!(o instanceof SimpleVertex))
			return false;
		return (this.key == ((SimpleVertex)o).key);
	}
	
	/**
	 * Finds edge from this vertex to vertex with key {@code num}
	 * @param num key of the other vertex
	 * @return The edge to the other vertex, or null if there is no edge connecting these vertices.
	 */
	public WeightedEdge getEdgeTo(int num) {
		if (this.key <= num)
			return outEdges.get(Integer.valueOf(num));
		return inEdges.get(Integer.valueOf(num));
	}
	
	/**
	 * @return List of pairs. Each pair contain neighbor vertex and an edge to this neighbor.
	 */
	public List<EdgeVertexPair> getNeighbors() {
		List<EdgeVertexPair> res = new ArrayList<EdgeVertexPair>(getDegree());
		for (WeightedEdge edge : outEdges.values())
			res.add(new EdgeVertexPair(edge, edge.getEnd()));
		for (WeightedEdge edge : inEdges.values())
			res.add(new EdgeVertexPair(edge, edge.getStart()));
		return res;
	}
	
	/**
	 * @return Degree of the vertex (the number of adjacent edges)
	 */
	public int getDegree() {
		return outEdges.size() + inEdges.size();
	}
	
	/**
	 * @return Sum of weights of the adjacent edges. Weights of self-loops are counted twice. 
	 */
	public int getTotalWeight() {
		int res = 0;
		for (WeightedEdge edge : outEdges.values())
			res += edge.getWeight();
		for (WeightedEdge edge : inEdges.values())
			res += edge.getWeight();
		return res;
	}
	
	public void fixSize() {
		//
	}
	
	/**
	 * @return List of adjacent edges leading to vertices
	 *  with key larger or equals to key of this vertex.  
	 */
	public List<WeightedEdge> getOwnedEdges() {
		List<WeightedEdge> res = new ArrayList<WeightedEdge>(outEdges.size());
		res.addAll(outEdges.values());
		return res;
	}

	/**
	 * @return Identifier of the vertex.
	 */
	public int getId() {
		return id;
	}

	/**
	 * Set identifier of the vertex
	 * @param id Identifier
	 */
	public void setId(int id) {
		this.id = id;
	}
	
	@Override
	public String toString() {
		return "<" + key + "," + id + ">";
	}
}
