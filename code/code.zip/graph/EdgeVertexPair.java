package graph;

class EdgeVertexPair {
	private final WeightedEdge edge;
	private final SimpleVertex vertex;
	
	public EdgeVertexPair(WeightedEdge edge, SimpleVertex vertex) {
		super();
		this.edge = edge;
		this.vertex = vertex;
	}

	public WeightedEdge getEdge() {
		return edge;
	}

	public SimpleVertex getVertex() {
		return vertex;
	}

}
