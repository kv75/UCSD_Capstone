package graph;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Queue;

import util.IndexedIntMaxPriorityQueue;

/**
 * Provides method split to partition network graph using algorithm with predefined leaders.
 * 
 * @author Viacheslav Krakhotin.
 *
 */
public class LeadersSolver {

	private final DirectedGraph graph;
	private final LeadersVertex[] vertices;
	private final int numVertices;
	private int damping;
	private int[] componentLeaders;
	private IndexedIntMaxPriorityQueue[] componentQueues;
	private double modularity;

	public LeadersSolver(DirectedGraph graph) {
		super();
		this.graph = graph;
		this.numVertices = graph.getNumVertices();
		this.vertices = new LeadersVertex[numVertices];
		for (int vertexId = 0; vertexId < numVertices; vertexId ++ ) {
			InOutVertex v = graph.getVertexById(vertexId);
			vertices[vertexId] = new LeadersVertex(v);
		}
		this.modularity = 0.;
	}

	/**
	 * Finds clusters around predefined leaders
	 * @param sources List of leader vertices.
	 * @param calcModularity If true, calculate modularity of the obtained partition.
	 * @return List of subgraphs.
	 *  ComponentId of the subgraph is the number of leader vertex.
	 */
	public List<GraphComponent> split(List<Integer> sources, boolean calcModularity) {
		damping = numVertices;
		massBFS(sources);
		int cap = numVertices;
		initQueues(componentLeaders.length);
		while ((cap > 0) && (changeLeaders() > 0)) {
			cap --; // To ensure that we don't enter into infinite loop.
		}
		componentQueues = null;
		// Free memory that was occupied by priority queues.
		// It is useful since we are going to use more memory while constructing subcomponents.
		System.gc();
		return divideByComponentId(calcModularity);
	}
	
	/**
	 * Performs breadth-first search using multiple sources.
	 * For each vertex, this method finds the closest source to it
	 *  and assigns this vertex to corresponding component.
	 *  Component 0 contains all vertices that are unreachable
	 *  from the input sources.
	 * @param sources Numbers of source vertices
	 * @return List of components. Index of the component in the list
	 *  is its identifier; value of the component is its source vertex.
	 */
	private void massBFS(List<Integer> sources) {
		ArrayList<Integer> res = new ArrayList<Integer>();
		Queue<LeadersVertex> queue = new ArrayDeque<LeadersVertex>();
		res.add(-1); // default component (index 0) for unreachable nodes 
		for (Integer source : sources) {
			InOutVertex vertex = graph.getVertexByKey(source);
			if (vertex != null) {
				res.add(vertex.getKey());
				LeadersVertex extVertex = vertices[vertex.getId()]; 
				extVertex.setComponentId(res.size() - 1);
				queue.offer(extVertex);
			}
		}
		LeadersVertex currVertex = queue.poll();
		while (currVertex != null) {
			int leader = currVertex.getComponentId();
			for (LeadersVertex neighbor : currVertex.getNeighbors()) {
				if (neighbor.getComponentId() == 0) {
					neighbor.setComponentId(leader);
					queue.offer(neighbor);
				}
			}
			currVertex = queue.poll();
		}
		this.componentLeaders = new int[res.size()];
		for (int i = 0; i < res.size(); i++)
			componentLeaders[i] = res.get(i);
	}

	/**
	 * Initializes indexed priority queues for all vertices.
	 *  Each queue contains weights of components for the vertex. 
	 * @param queueSize Maximum size of the queue.
	 */
	private void initQueues(int queueSize) {
		this.componentQueues = new IndexedIntMaxPriorityQueue[numVertices];
		for (int id = 0; id < numVertices; id++) {
			IndexedIntMaxPriorityQueue queue = new IndexedIntMaxPriorityQueue(queueSize);
			queue.incrementValue(vertices[id].getComponentId(), damping);
			componentQueues[id] = queue;
		}
		for (int id = 0; id < numVertices; id++) {
			LeadersVertex vertex = vertices[id];
			int currComponentId = vertex.getComponentId();
			for (LeadersVertex neighbor : vertex.getNeighbors())
				componentQueues[neighbor.getId()].incrementValue(currComponentId, damping);
			for (LeadersVertex neighbor : vertex.getNeighbors2())
				componentQueues[neighbor.getId()].incrementValue(currComponentId);
		}
	}

	/**
	 * Changes components of the vertices according to the rule described in the report. 
	 * @return Number of vertices that has changed their components.
	 */
	private int changeLeaders() {
		// Map of vertex to identifier of its new component.
		HashMap<LeadersVertex, Integer> newComponents = new HashMap<LeadersVertex, Integer>();
		// We have to be very careful to not update component queue for a vertex
		// before finding out if it has to change its component.
		// First we have to analyze current state of queues
		// and determine new components without changing queues.
		for (int id = 0; id < numVertices; id ++) {
			LeadersVertex vertex = vertices[id];
			IndexedIntMaxPriorityQueue currQueue = componentQueues[vertex.getId()];
			IndexedIntMaxPriorityQueue.KeyValue candidate = currQueue.peek();
			int currComponent = vertex.getComponentId();
			if ((candidate != null) && (candidate.getKey() != currComponent) && (candidate.getValue() > currQueue.getValue(currComponent))) {
				newComponents.put(vertex, candidate.getKey());
			}
		}
		// Now for each vertex that has changed its component,
		// we update its queue, as well of queues of its' neighbors and 2-hop neighbors. 
		for (Map.Entry<LeadersVertex, Integer> entry : newComponents.entrySet()) {
			LeadersVertex vertex = entry.getKey();
			int oldComponent = vertex.getComponentId();
			int newComponent = entry.getValue();
			vertex.setComponentId(newComponent);
			IndexedIntMaxPriorityQueue queue = componentQueues[vertex.getId()];
			queue.decrementValue(oldComponent, damping);
			queue.incrementValue(newComponent, damping);
			for (LeadersVertex neighbor : vertex.getNeighbors()) {
				queue = componentQueues[neighbor.getId()];
				queue.decrementValue(oldComponent, damping);
				queue.incrementValue(newComponent, damping);
			}
			for (LeadersVertex neighbor : vertex.getNeighbors2()) {
				queue = componentQueues[neighbor.getId()];
				queue.decrementValue(oldComponent);
				queue.incrementValue(newComponent);
			}
		}
		return newComponents.size();
	}

	/**
	 * Splits the graph according to componentId's of the vertices.
	 * @param calcModularity If true, calculate modularity of the obtained partition.
	 * @return List of connected subgraphs. Each of these subgraphs contains vertices
	 *  with the same componentId. ComponentId of the subgraph is the number
	 *  of source vertex for the component.
	 */
	private List<GraphComponent> divideByComponentId(boolean calcModularity) {
		if (calcModularity)
			modularity = calculateModularity();
		HashMap<Integer, List<InOutVertex>> components = new HashMap<Integer, List<InOutVertex>>(2 * componentLeaders.length);
		for (int id = 0; id < numVertices; id ++) {
			Integer parent = vertices[id].getComponentId();
			List<InOutVertex> component = components.get(parent);
			if (component == null) {
				component = new ArrayList<InOutVertex>();
				components.put(parent, component);
			}
			component.add(graph.getVertexById(id));
		}
		List<GraphComponent> res = new ArrayList<GraphComponent>();
		for (Map.Entry<Integer, List<InOutVertex>> entry : components.entrySet()) {
			DirectedGraph subGraph = graph.getSubgraph(entry.getValue());
			int key = entry.getKey();
			if ((key >= 0) && (key < componentLeaders.length)) {
				key = componentLeaders[key];
			}
			subGraph.setComponentId(key);
			res.addAll(subGraph.getConnectedComponents(true));
		}
		return res;
	}

	/**
	 * Calculate modularity of the obtained partition
	 * @return Modularity of the obtained partition
	 */
	private double calculateModularity() {
		// sumOfProducts is the sum of products of vertex degrees (undirected, or out-degrees)
		// for each vertex pair within the same component;
		// each vertex pair is accounted twice (for both orders of vertices);
		// pairs with the same vertices are accounted once
		long sumOfProducts = 0;
		// numInnerEdges is the number of directed edges within the same component,
		// or twice the number of undirected edges within the same component
		int numInnerEdges = 0;
		// numTotalEdges is the number of directed edges in the graph,
		// or twice the number of undirected edges in the graph
		int numTotalEdges = 0;
		for (int id1 = 0; id1 < numVertices; id1 ++) {
			InOutVertex vertex1 = graph.getVertexById(id1);
			int component1 = vertices[id1].getComponentId();
			for (int id2 = 0; id2 < numVertices; id2 ++) {
				InOutVertex vertex2 = graph.getVertexById(id2);
				if (vertices[id2].getComponentId() == component1) {
					sumOfProducts += vertex1.getOutDegree() * vertex2.getOutDegree();
				}
			}
			for (DirectedEdge edge : vertex1.getEdges()) {
				numTotalEdges ++;
				if (vertices[edge.getEnd().getId()].getComponentId() == component1)
					numInnerEdges ++;
			}
		}
		return (numInnerEdges - (sumOfProducts + 0.) / numTotalEdges) / numTotalEdges;
	}
	
	/**
	 * @return Modularity of the obtained partition
	 */
	public double getModularity() {
		return modularity;
	}

	private class LeadersVertex {

		private final int id;
		private int componentId;
		private ArrayList<LeadersVertex> outNeighbors;
		private ArrayList<LeadersVertex> outNeighbors2;
		
		public LeadersVertex(InOutVertex source) {
			super();
			this.id = source.getId();
			this.componentId = 0;
			this.outNeighbors = null;
			this.outNeighbors2 = null;
		}

		public int getId() {
			return id;
		}

		public int getComponentId() {
			return componentId;
		}

		public void setComponentId(int componentId) {
			this.componentId = componentId;
		}

		public List<LeadersVertex> getNeighbors() {
			if (outNeighbors == null) {
				InOutVertex source = graph.getVertexById(id);
				outNeighbors = new ArrayList<LeadersVertex>(source.getEdges().size());
				for (DirectedEdge edge : source.getEdges())
					outNeighbors.add(vertices[edge.getEnd().getId()]);
				outNeighbors.trimToSize();
			}
			return outNeighbors;
		}

		public List<LeadersVertex> getNeighbors2() {
			if (outNeighbors2 == null) {
				boolean[] visited = new boolean[numVertices];
				visited[id] = true;
				for (LeadersVertex neighbor : getNeighbors())
					visited[neighbor.getId()] = true;
				outNeighbors2 = new ArrayList<LeadersVertex>(getNeighbors().size());
				for (LeadersVertex neighbor : getNeighbors()) {
					for (LeadersVertex neighbor2 : neighbor.getNeighbors()) {
						if (!visited[neighbor2.getId()]) {
							visited[neighbor2.getId()] = true;
							outNeighbors2.add(neighbor2);
						}
					}
				}
				outNeighbors2.trimToSize();
			}
			return outNeighbors2;
		}

		@Override
		public final int hashCode() {
			// Just return hashCode of the id, since id is unique.
			return Integer.valueOf(id).hashCode();
		}
		
		@Override
		public final boolean equals(Object o) {
			if (o == this)
				return true;
			if (!(o instanceof LeadersVertex))
				return false;
			return (this.id == ((LeadersVertex)o).id);
		}

	}

}
