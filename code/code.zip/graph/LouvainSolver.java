package graph;

import java.io.PrintWriter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Provides method split to partition graph using Louvain algorithm.
 * 
 * @author Viacheslav Krakhotin.
 *
 */
public class LouvainSolver {

	private final UndirectedGraph graph;
	private final LouvainVertex[] vertices;
	private LouvainComponent[] components;
	private IterationMode mode;
	private double modularity;
	private PrintWriter out;
	
	/**
	 * Iteration order of vertices for Louvain algorithm.
	 * ID - order by ID.
	 * BFS - breadth-first search order.
	 * RANDOM - random order.
	 */
	public enum IterationMode { ID, BFS, RANDOM };
	
	public LouvainSolver(UndirectedGraph graph, double modularity, PrintWriter out) {
		super();
		this.out = out;
		this.graph = graph;
		this.vertices = new LouvainVertex[graph.getNumVertices()];
		for (int vertexId = 0; vertexId < vertices.length; vertexId ++ ) {
			vertices[vertexId] = new LouvainVertex(graph.getVertexById(vertexId));
		}
		this.modularity = modularity;
		testMessage("New graph with modularity " + this.modularity);
		testMessage("Initial modularity " + initialModularity());
	}

	public LouvainSolver(UndirectedGraph graph, PrintWriter out) {
		this(graph, 0., out);
		this.modularity = initialModularity();
		testMessage("Initial modularity " + this.modularity);
	}

	public LouvainSolver(UndirectedGraph graph) {
		this(graph, null);
	}

	/**
	 * Splits graph into components using Louvain algorithm.
	 * @param mode Order of vertices during iteration
	 * @param calcModularity If true, calculate modularity of the obtained partition.
	 * @return List of subgraphs.
	 */
	public List<GraphComponent> split(IterationMode mode, boolean calcModularity) {
		return getComponentList(splitInternal(mode), calcModularity);
	}
	
	/**
	 * Maps vertices to components for this graph.
	 * @param mode Order of vertices during iteration
	 * @return Map of keys of the vertices to the components id's. 
	 */
	private Map<Integer, Integer> splitInternal(IterationMode mode) {
		this.mode = mode;
		this.components = new LouvainComponent[vertices.length];
		for (int id = 0; id < vertices.length; id++) {
			// Assign separate component for each vertex.
			components[id] = new LouvainComponent(vertices[id]);
		}
		// If we can not gain in modularity for this graph,
		// construct new map and immediately return it to parent graph.
		if (louvainChanges() == 0)
			return componentMap();
		// Iterations of the Louvain algorithm.
		while (louvainChanges() > 0) {};
		// Construct child graph from components and run Louvain for it. 
		return componentMap(new LouvainSolver(graphLouvainComponents(), modularity, out).splitInternal(mode));
	}
	
	/**
	 * For each vertex, try to reassign it to new component.
	 * @return Total number of changes.
	 */
	private int louvainChanges() {
		int numChanges = 0;
		Iterator<LouvainVertex> iter;
		switch (mode) {
		case BFS:
			iter = getBfsIterator();
			break;
		case ID:
			iter = getVertexIterator();
			break;
		case RANDOM:
			iter = getRandomIterator();
			break;
		default:
			iter = getVertexIterator();
		}
		while (iter.hasNext()) {
			// for each vertex of the graph in some order
			LouvainVertex vertex = iter.next();
			int oldComponentId = vertex.getComponentId();
			LouvainComponent oldComponent = components[oldComponentId];
			// remove vertex from the component to which it is currently assigned
			oldComponent.removeVertex(vertex);
			// calculate loss in modularity by removing it
			double oldBonus = oldComponent.bonusFromVertex(vertex);
			double maxBonus = oldBonus;
			LouvainComponent bestComponent = oldComponent;
			for (Integer newComponentId : vertex.neighborComponents()) {
				if (newComponentId != oldComponentId) {
					// check each possible component among neighbors of the vertex
					LouvainComponent newComponent = components[newComponentId];
					double bonus = newComponent.bonusFromVertex(vertex);
					if (bonus > maxBonus) {
						maxBonus = bonus;
						bestComponent = newComponent;
					}
				}
			}
			if (!bestComponent.equals(oldComponent)) {
				modularity += 2 * (maxBonus - oldBonus) / graph.getTotalWeight();
				numChanges ++;
				testMessage("" + modularity);
			}
			// add vertex to the component that gives maximum gain in modularity
			bestComponent.addVertex(vertex);
		}
		return numChanges;
	}
	
	/**
	 * Construct child graph from the components of current graph.
	 * @return New graph
	 */
	private UndirectedGraph graphLouvainComponents() {
		UndirectedGraph res = new UndirectedGraph();
		for (int id = 0; id < components.length; id++) {
			LouvainComponent component = components[id];
			if (!component.isEmpty()) {
				// add all non-empty components as vertices of child graph
				res.addVertex(component.getComponentId());
				testMessage(component.toString());
			}
		}
		testMessage("Number of vertices " + res.getNumVertices());
		for (int id = 0; id < vertices.length; id++) {
			int vertexComponentId = vertices[id].getComponentId();
			for (WeightedEdge edge : graph.getVertexById(id).getOwnedEdges()) {
				// for each edge of current graph, add its weight to the edge that connects vertices
				// corresponding to components assigned to ends of the current edge;
				// if components are the same, there will be self-loop 
				res.addEdge(vertexComponentId, vertices[edge.getEnd().getId()].getComponentId(), edge.getWeight());
			}
		}
		// after construction of new graph, do not forget to call fixSize for it 
		res.fixSize();
		return res;
	}
	
	/**
	 * Creates map of vertices to components.
	 * @return Map of keys of the vertices to the components id's.
	 */
	private Map<Integer, Integer> componentMap() {
		Map<Integer, Integer> res = new HashMap<Integer, Integer>();
		for (int id = 0; id < vertices.length; id++) {
			res.put(graph.getVertexById(id).getKey(), vertices[id].getComponentId());
		}
		testMessage("Base component map : " + res);
		return res;
	}

	/**
	 * Update map of vertices to component using map for child graph.
	 * @param vertexToComponent Map of keys of the vertices of child graph to the components id's.
	 * @return Map of keys of the vertices of current graph to the components id's.
	 */
	private Map<Integer, Integer> componentMap(Map<Integer, Integer> vertexToComponent) {
		Map<Integer, Integer> res = new HashMap<Integer, Integer>();
		for (int id = 0; id < vertices.length; id++) {
			res.put(graph.getVertexById(id).getKey(), vertexToComponent.get(vertices[id].getComponentId()));
		}
		testMessage("Component map : " + res);
		return res;
	}

	/**
	 * Splits graph into components using map of vertices to components.
	 * @param vertexToComponent Map of keys of the vertices to the components id's.
	 * @param calcModularity If true, calculate modularity of the obtained partition.
	 * @return List of subgraphs.
	 */
	private List<GraphComponent> getComponentList(Map<Integer, Integer> vertexToComponent, boolean calcModularity) {
		if (calcModularity)
			modularity = calculateModularity(vertexToComponent);
		List<GraphComponent> res = new ArrayList<GraphComponent>();
		// collect vertices to their components
		// create map of component id's to list of vertices for this component
		HashMap<Integer, ArrayList<SimpleVertex>> componentToVertices = new HashMap<Integer, ArrayList<SimpleVertex>>();
		for (Map.Entry<Integer, Integer> entry : vertexToComponent.entrySet()) {
			SimpleVertex vertex = graph.getVertexByKey(entry.getKey());
			ArrayList<SimpleVertex> vertexList = componentToVertices.get(entry.getValue());
			if (vertexList == null) {
				vertexList = new ArrayList<SimpleVertex>();
				componentToVertices.put(entry.getValue(), vertexList);
			}
			vertexList.add(vertex);
		}
		int componentId = 0;
		for (ArrayList<SimpleVertex> vertexList : componentToVertices.values()) {
			// create subgraph for each component
			UndirectedGraph component = graph.getSubgraph(vertexList);
			component.setComponentId(componentId);
			res.add(component);
			testMessage("Component " + componentId + " : " + vertexList);
			componentId ++;
		}
		return res;
	}
	
	/**
	 * Calculate modularity of the partition
	 * @param vertexToComponent Map of keys of the vertices to the components id's.
	 * @return Modularity of the partition corresponding to map vertexToComponent
	 */
	private double calculateModularity(Map<Integer, Integer> vertexToComponent) {
		// sumOfProducts is the sum of products of vertex weighted degrees
		// (sum of weights of incident edges) for each vertex pair within the same component;
		// each vertex pair is accounted twice (for both orders of vertices);
		// pairs with the same vertices are accounted once
		long sumOfProducts = 0;
		// numInnerEdges is twice the sum of weights of edges within the same component
		int numInnerEdges = 0;
		// numTotalEdges is twice the sum of weights of all edges in the graph
		int numTotalEdges = 0;
		for (int id1 = 0; id1 < vertices.length; id1 ++) {
			long weight1 = vertices[id1].getTotalWeight();
			int component1 = vertexToComponent.get(graph.getVertexById(id1).getKey());
			for (int id2 = 0; id2 < vertices.length; id2 ++) {
				if (vertexToComponent.get(graph.getVertexById(id2).getKey()) == component1) {
					sumOfProducts += weight1 * vertices[id2].getTotalWeight();
				}
			}
		}
		for (WeightedEdge edge : graph.getEdges()) {
			int twiceWeight = 2 * edge.getWeight();
			numTotalEdges += twiceWeight; 
			if (vertexToComponent.get(edge.getStart().getKey()) == vertexToComponent.get(edge.getEnd().getKey())) {
				numInnerEdges += twiceWeight;
			}
		}
		testMessage("numInnerEdges " + numInnerEdges);
		testMessage("numTotalEdges " + numTotalEdges);
		testMessage("sumOfProducts " + sumOfProducts);
		return (numInnerEdges - (sumOfProducts + 0.) / numTotalEdges) / numTotalEdges;
	}
	
	private double initialModularity() {
		long sumOfProducts = 0;
		int numInnerEdges = 0;
		int numTotalEdges = 0;
		for (int id1 = 0; id1 < vertices.length; id1 ++) {
			long weight1 = vertices[id1].getTotalWeight();
			testMessage("Vertex " + id1 + ", weight " + weight1);
			sumOfProducts += weight1 * weight1;
		}
		for (WeightedEdge edge : graph.getEdges()) {
			int twiceWeight = 2 * edge.getWeight();
			numTotalEdges += twiceWeight; 
			if (edge.getStart().getKey() == edge.getEnd().getKey()) {
				numInnerEdges += twiceWeight;
			}
		}
		testMessage("numInnerEdges " + numInnerEdges);
		testMessage("numTotalEdges " + numTotalEdges);
		testMessage("sumOfProducts " + sumOfProducts);
		return (numInnerEdges - (sumOfProducts + 0.) / numTotalEdges) / numTotalEdges;
	}
	
	private Iterator<LouvainVertex> getVertexIterator() {
		return new VertexIterator();
	}

	private Iterator<LouvainVertex> getBfsIterator() {
		return new BfsIterator(); 
	}
	
	private Iterator<LouvainVertex> getRandomIterator() {
		return new RandomIterator();
	}

	/**
	 * @return Modularity of the obtained partition
	 */
	public double getModularity() {
		return modularity;
	}
	
	private void testMessage(String s) {
		if (out != null)
			out.println(s);
	}
	
	private class LouvainVertex {
		
		private final int id;
		private final int totalWeight;
		private final List<EdgeVertexPair> neighbors;
		private int componentId;
		
		public LouvainVertex(SimpleVertex source) {
			this.id = source.getId();
			this.totalWeight = source.getTotalWeight();
			this.componentId = id;
			// this cache of neighbors is extremely useful
			this.neighbors = source.getNeighbors();
		}

		public int getId() {
			return id;
		}

		public int getComponentId() {
			return componentId;
		}

		public void setComponentId(int componentId) {
			this.componentId = componentId;
		}

		public int getTotalWeight() {
			return totalWeight;
		}

		public List<EdgeVertexPair> getNeighbors() {
			return neighbors;
		}

		public Set<Integer> neighborComponents() {
			Set<Integer> res = new HashSet<Integer>();
			for (EdgeVertexPair pair : neighbors) {
				if (pair.getVertex().getId() != id) {
					res.add(vertices[pair.getVertex().getId()].getComponentId());
				}
			}
			return res;
		}
		
		@Override
		public final int hashCode() {
			// Just return hashCode of the id, since id is unique.
			return Integer.valueOf(id).hashCode();
		}
		
		@Override
		public final boolean equals(Object o) {
			if (o == this)
				return true;
			if (!(o instanceof LouvainVertex))
				return false;
			return (this.id == ((LouvainVertex)o).id);
		}

		@Override
		public String toString() {
			return "{" + id + "," + componentId + "}";
		}
	}
	
	private class VertexIterator implements Iterator<LouvainVertex> {
		
		private final int numVertices;
		private int nextId;
		
		public VertexIterator() {
			this.numVertices = vertices.length;
			this.nextId = 0;
		}

		@Override
		public boolean hasNext() {
			return nextId < numVertices;
		}

		@Override
		public LouvainVertex next() {
			if (nextId >= numVertices)
				throw new NoSuchElementException();
			LouvainVertex v = vertices[nextId];
			nextId ++;
			return v;
		}
	}

	private class BfsIterator implements Iterator<LouvainVertex> {

		private ArrayDeque<LouvainVertex> queue;
		private final boolean[] visited;
		private final int numVertices;
		private int visitedCount;
		private int nextId;
		
		public BfsIterator() {
			this.numVertices = vertices.length;
			this.queue = new ArrayDeque<LouvainVertex>(numVertices);
			this.visited = new boolean[numVertices];
			this.visitedCount = 0;
			this.nextId = 0;
		}
		
		@Override
		public boolean hasNext() {
			return (visitedCount < numVertices);
		}

		@Override
		public LouvainVertex next() {
			LouvainVertex v = queue.poll();
			while (v == null && nextId < numVertices) {
				if (!visited[nextId]) {
					visited[nextId] = true;
					v = vertices[nextId];
				}
				nextId++;
			}
			if (v == null)
				throw new NoSuchElementException();
			visitedCount ++;
			for (EdgeVertexPair pair : v.getNeighbors()) {
				int neighborId = pair.getVertex().getId();
				if (!visited[neighborId]) {
					visited[neighborId] = true;
					queue.add(vertices[neighborId]);
				}
			}
			return v;
		}
	}	

	private class RandomIterator implements Iterator<LouvainVertex> {
		
		private final int numVertices;
		private int nextId;
		private int[] randomVertices;
		
		public RandomIterator() {
			this.numVertices = vertices.length;
			this.nextId = 0;
			this.randomVertices = new int[vertices.length];
			for (int id = 0; id < vertices.length; id ++) {
				randomVertices[id] = id;
			}
			// To obtain iteration in random order,
			// we will iterate through array, as for VertexIterator,
			// but we shuffle the array at the beginning.
		    Random rnd = ThreadLocalRandom.current();
		    for (int i = randomVertices.length - 1; i > 0; i--)
		    {
		      int index = rnd.nextInt(i + 1);
		      int id = randomVertices[index];
		      randomVertices[index] = randomVertices[i];
		      randomVertices[i] = id;
		    }
		}

		@Override
		public boolean hasNext() {
			return nextId < numVertices;
		}

		@Override
		public LouvainVertex next() {
			if (nextId >= numVertices)
				throw new NoSuchElementException();
			LouvainVertex v = vertices[randomVertices[nextId]];
			nextId ++;
			return v;
		}
	}

	private class LouvainComponent {
		private final int componentId;
		private int totalWeight;
		private ArrayList<LouvainVertex> localVertices;
		//private Set<LouvainVertex> localVertices;
		// ArrayList is faster than HashSet here, in spite of remove operations
		
		public LouvainComponent(LouvainVertex vertex) {
			super();
			this.localVertices = new ArrayList<LouvainVertex>();
			this.localVertices.add(vertex);
			this.componentId = vertex.getId();
			this.totalWeight = vertex.getTotalWeight();
			vertex.setComponentId(vertex.getId());
		}

		@Override
		public final int hashCode() {
			// Just return hashCode of the componentId, since componentIds are unique.
			return Integer.valueOf(componentId).hashCode();
		}
		
		@Override
		public final boolean equals(Object o) {
			if (o == this)
				return true;
			if (!(o instanceof LouvainComponent))
				return false;
			return (this.componentId == ((LouvainComponent)o).componentId);
		}
		
		public void addVertex(LouvainVertex vertex) {
			localVertices.add(vertex);
			vertex.setComponentId(this.componentId);
			for (EdgeVertexPair pair : vertex.getNeighbors()) {
				totalWeight += pair.getEdge().getWeight();
			}
		}
		
		public void removeVertex(LouvainVertex vertex) {
			localVertices.remove(vertex);
			vertex.setComponentId(-1);
			for (EdgeVertexPair pair : vertex.getNeighbors()) {
				totalWeight -= pair.getEdge().getWeight();
			}
		}

		public int getComponentId() {
			return componentId;
		}
		
		public double bonusFromVertex(LouvainVertex vertex) {
			// kInner is sum weight of edges that leads from given vertex
			// to vertices in this component.
			int kInner = 0;
			for (EdgeVertexPair pair : vertex.getNeighbors()) {
				LouvainVertex neighbor = vertices[pair.getVertex().getId()];
				if (!neighbor.equals(vertex) && (neighbor.getComponentId() == componentId)) {
					// We neglect self-loops here, as they give the same contribution
					// to every tested component.
					kInner += pair.getEdge().getWeight();
				}
			}
			long product = (long)totalWeight * (long)vertex.getTotalWeight();
			return kInner - (product + 0.) / graph.getTotalWeight();
		}
		
		public boolean isEmpty() {
			return localVertices.size() == 0;
		}

		@Override
		public String toString() {
			return "[[" + localVertices.toString() + "]]";
		}
	}
}
